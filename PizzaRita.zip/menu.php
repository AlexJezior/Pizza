<?php require 'includes/header.php'; ?>


<div class="small-12 medium-9 large-10 columns">

  <ul class="accordion" data-accordion>
    <li class="accordion-item is-active" data-accordion-item>
      <a href="#" class="accordion-title">Regular Prices</a>
      <div class="accordion-content" data-tab-content>
        Plain ole' regular prices.
      </div>
    </li>
    <li class="accordion-item" data-accordion-item>
      <a href="#" class="accordion-title">Specials</a>
      <div class="accordion-content" data-tab-content>
        The specials.
      </div>
    </li>
    <li class="accordion-item" data-accordion-item>
      <a href="#" class="accordion-title">Sides</a>
      <div class="accordion-content" data-tab-content>
        Breadsticks, wings, soda
      </div>
    </li>
  </ul>

</div>


<?php require 'includes/footer.php'; ?>