<?php require 'includes/header.php'; ?>


<div class="small-12 medium-9 large-10 columns text-center">
  <div class="row">
    <h3 class="small-12" id="challenge-header">5lb Challenge</h3>
  </div>
  <br />
  <br />
  <div class="row">

    <div class="small-12 medium-6 columns text-left">
      <p>Take down our 5lb Pizza and earn: Your picture on the Wall of Champions, 50.00 Cash to your Favorite Charity, $50.00 in Rita Bucks & BRAGGING RIGHTS! We'll ADD 10.00 in Rita Bucks each time someone tries and fails. Just 25.99 & you get a T shirt, just for trying (Win or Lose) This could get real profitable, real fast!! Current "Rita Bucks" count is 50.00 after Jeff beat it on 12/30.</p>

      <p>Call Brian, the owner, @ 953-1486 to schedule your chance at glory!</p>
    </div>

    <div class="small-12 medium-6 columns">
      <p><span class="button alert">OFFICIAL RULES!!!</span>

        <ul class=" text-left">
          <li>30 minute time limit</li>
          <li>1 person must finish entire pizza</li>
          <li>WE DO MAKE SUBSTITUTIONS!!!!</li>
          <li>Winners can come back and compete again AFTER 1 year</li>
        </ul>
      </p>
    </div>


    <div class="small-12 columns"><br /><br /><br />
      <p>We also have a CHARITY CHALLENGE: Get donations (up to 100.00 per contestant). We match the contributions collected by every successful challenger. Get as many contestants as you want. Call Brian @ 953-1486 to get started.</p>
    </div>

  </div>

</div>


<?php require 'includes/footer.php'; ?>